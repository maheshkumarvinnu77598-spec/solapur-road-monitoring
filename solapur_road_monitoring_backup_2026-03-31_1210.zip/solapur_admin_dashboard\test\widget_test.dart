import 'package:flutter_test/flutter_test.dart';

void main() {
  test('basic sanity check', () {
    expect(1 + 1, 2);
  });
}
